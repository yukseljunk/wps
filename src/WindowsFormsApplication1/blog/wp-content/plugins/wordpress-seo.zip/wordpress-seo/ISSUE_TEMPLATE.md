### What did you expect to happen?

### What happened instead?

### How can we reproduce this behavior?

Can you provide a link to a page which shows this issue?

### Technical info
* WordPress version:
* Yoast SEO version:
