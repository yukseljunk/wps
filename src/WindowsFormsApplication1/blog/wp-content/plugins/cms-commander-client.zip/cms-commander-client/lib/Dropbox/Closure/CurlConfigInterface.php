<?php

interface Dropbox_Closure_CurlConfigInterface
{
    public function configure(Dropbox_Curl $curl);
}
