<?php
if (!defined('ABSPATH')) exit;

class IRP_OtherTag extends IRP_HTMLTag {
    public function __construct() {
        parent::__construct();
    }

    public function write(IRP_HTMLContext $context) {
        parent::write($context);
    }
}
