=== Adman ===
Contributors: uberdose
Donate link: http://wp.uberdose.com/contribute/
Tags: post,google,adsense,ads
Requires at least: 2.0.2
Tested up to: 2.1.3
Stable tag: trunk

Lets you insert your ad-code (like AdSense) directly before or in the middle of your post content
or wherever you want without having to edit your template.

== Description ==

**This plugin is no longer supported or maintained.**

Lets you insert your ad-code (like AdSense) directly before or in the middle of your post content
or wherever you want without having to edit your template.

You can specify an ad-code to appear *before* your actual post content and one to appear in the middle of it.

Just install it, then go to Options -> AdMan. There you can set your ad-codes. The one to appear *before* your
post content will appear before your content, the one to appear in the middle will be calculated to appear
right in the middle of your posts (between tag groups, like paragraphs or divs), or where you inserted &lt;!-- adman --> in it.

== Installation ==

1. Unzip into your `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
