<div id="donation" class="postbox">
    <h3 class="hndle"><?php echo __('Say "Thank you"','find-duplicates') ?></h3>
    <div class="inside">
    <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
        <input type="hidden" name="cmd" value="_s-xclick">
        <input type="hidden" name="hosted_button_id" value="4S7SVMALSSZ2Y">
        <?php echo __('Say "Thank you" and further more free plugins!', 'find-duplicates'); ?> <input type="image" src="https://www.paypalobjects.com/de_DE/DE/i/btn/btn_donate_SM.gif" border="0" name="submit" alt="Jetzt einfach, schnell und sicher online bezahlen – mit PayPal.">
        <img alt="" border="0" src="https://www.paypalobjects.com/de_DE/i/scr/pixel.gif" width="1" height="1">
    </form>
    </div>
</div>